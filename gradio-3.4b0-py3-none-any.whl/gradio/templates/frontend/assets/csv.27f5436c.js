import { d as dsvFormat } from './dsv.7fe76a93.js';

var csv = dsvFormat(",");

var csvParse = csv.parse;
var csvParseRows = csv.parseRows;

export { csvParse as a, csvParseRows as c };

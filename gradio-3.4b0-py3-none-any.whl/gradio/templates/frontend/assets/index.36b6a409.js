export { Q as Component } from './index.293eee2d.js';

const modes = ["static"];

export { modes };

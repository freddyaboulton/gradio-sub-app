export { C as Component } from './Column.3fc98c5f.js';
import './index.293eee2d.js';
import './styles.c72835fa.js';

const modes = ["static"];

export { modes };
